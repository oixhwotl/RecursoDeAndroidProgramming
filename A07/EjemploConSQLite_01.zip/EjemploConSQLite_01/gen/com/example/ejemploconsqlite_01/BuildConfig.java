/** Automatically generated file. DO NOT MODIFY */
package com.example.ejemploconsqlite_01;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}