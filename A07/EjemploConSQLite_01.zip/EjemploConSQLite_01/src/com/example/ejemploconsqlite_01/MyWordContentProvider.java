package com.example.ejemploconsqlite_01;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

public class MyWordContentProvider extends ContentProvider
{
	private static final String TAG = "MyWordContentProvider";
	
	// used for the UriMacher
	private static final int URI_MYWORD_WORD = 20;
	private static final int URI_MYWORD_ID = 10;

	private static final String AUTHORITY = "com.example.ejemploconsqlite_01.contentprovider";

	private static final String BASE_PATH = "myword";
	public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY
	      + "/" + BASE_PATH);

	public static final String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE
	      + "/words";
	public static final String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE
	      + "/word";

	private static final UriMatcher mURIMatcher = new UriMatcher(UriMatcher.NO_MATCH);
	static {
		mURIMatcher.addURI(AUTHORITY, BASE_PATH, URI_MYWORD_WORD);
		mURIMatcher.addURI(AUTHORITY, BASE_PATH + "/#", URI_MYWORD_ID);
	}

	// database
	private SQLiteDatabase mDatabase;

	@Override
	public int delete (Uri arg0, String arg1, String[] arg2)
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public String getType (Uri uri)
	{
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Uri insert (Uri uri, ContentValues values)
	{
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public boolean onCreate ()
	{
		Log.v(TAG, "MyWordContentProvider()");
		MySQLiteOpenHelper openHelper = new MySQLiteOpenHelper(getContext());
		mDatabase = openHelper.getWritableDatabase();
		
		return (mDatabase != null);
	}
	
	@Override
	public Cursor query (Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder)
	{
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public int update (Uri uri, ContentValues values, String selection,
			String[] selectionArgs)
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
}
